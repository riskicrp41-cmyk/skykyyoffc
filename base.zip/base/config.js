const global = {
    owner: [IdOwner], // ganti jadi id mu
    botToken: "TokenBot", //isi token bot mu
}

module.exports = global;